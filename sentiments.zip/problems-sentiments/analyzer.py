import nltk

class Analyzer():
    """Implements sentiment analysis."""

    def __init__(self, positives="positive-words.txt", negatives="negative-words.txt"):
        """Initialize Analyzer."""

        # TODO

    def analyze(self, text):
        """Analyze text for sentiment, returning its score."""

        # TODO
        return 0
